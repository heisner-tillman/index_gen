# Boundary Operator Definition and Application
  
[[GDL_SummerSchool_Part1]] (Page 43)

![[assets/slide-43.jpg]]

## Front
Boundary Operator Definition and Application

## Back
The boundary operator `∂k` maps k-simplices to (k-1)-simplices. It is defined as a linear operator `∂k : Ck(K, R) → Ck-1(K, R)`. The formula is `∂k(v0, ..., vk) = Σ_{i=0 to k} (-1)^i (v0, ..., ^vi, ..., vk)`, where `(v0, ..., ^vi, ..., vk)` denotes the simplex obtained by dropping vertex `vi`.

For a 2-simplex (triangle) `(v0, v1, v2)`, the boundary is `∂(v0, v1, v2) = (v1, v2) - (v0, v2) + (v0, v1) = (v1, v2) + (v2, v0) + (v0, v1)`. This represents the oriented edges forming the perimeter of the triangle. Applying the boundary operator again to these edges results in the empty set, illustrating the property `∂∂ = 0`.
