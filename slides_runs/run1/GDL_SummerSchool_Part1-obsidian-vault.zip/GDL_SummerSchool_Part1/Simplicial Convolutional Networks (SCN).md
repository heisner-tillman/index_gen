# Simplicial Convolutional Networks (SCN)
  
[[GDL_SummerSchool_Part1]] (Page 61)

![[assets/slide-61.jpg]]

## Front
Simplicial Convolutional Networks (SCN)

## Back
SCNs extend Graph Convolutional Networks (GCNs) to simplicial complexes. Given:
- A simplicial complex $K$ with a normalized Hodge Laplacian $\Delta_k = \alpha L_k$ (where $\alpha > 0$).
- $k$-simplex features $X \in \mathbb{R}^{n_k \times d}$.
The simplicial equivalent of a GCN layer is defined as:
$Y := \sigma((I - \Delta_0)XW)$
where:
- $Y$ is the output feature matrix.
- $\sigma$ is an activation function.
- $I$ is the identity matrix.
- $\Delta_0$ is the 0-th order Hodge Laplacian.
- $X$ represents the input features.
- $W$ is a learnable weight matrix.
