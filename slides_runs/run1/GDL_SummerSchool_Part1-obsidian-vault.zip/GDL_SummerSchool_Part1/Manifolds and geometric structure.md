# Manifolds and geometric structure
  
[[GDL_SummerSchool_Part1]] (Page 6)

![[assets/slide-6.jpg]]

## Front
Manifolds and geometric structure

## Back
Not all spaces can be equipped with a purely geometrical structure, necessitating a chain of structural dependencies. Manifolds are spaces that are locally Euclidean, meaning regions (U) can be mapped to R^2 via charts (φ, ψ). While the manifold itself may lack a global geometric structure, local geometric properties, such as the inner product of tangent vectors (v, w) at a point q, can be defined on its tangent spaces (T_qM) using a metric tensor (g_q(v, w)).
