# Orientation Equivariance Condition
  
[[GDL_SummerSchool_Part1]] (Page 78)

![[assets/slide-78.jpg]]

## Front
Orientation Equivariance Condition

## Back
A function $f: C_k(K, \mathbb{R})^{F_1} \to C_k(K, \mathbb{R})^{F_2}$ is orientation equivariant if $f(\mathcal{T}\mathcal{B}, \mathbf{T}_k\mathbf{X}) = \mathbf{T}_k f(\mathcal{B}, \mathbf{X})$. Here, $\mathcal{T} = (\mathbf{T}_0, \dots, \mathbf{T}_d)$ where each $\mathbf{T}_i$ is a diagonal matrix with $\pm 1$ entries and $\mathbf{T}_0 = \mathbf{I}$. The transformed incidence matrices are $\mathcal{T}\mathcal{B} = (\mathbf{T}_0\mathbf{B}_1\mathbf{T}_1, \dots, \mathbf{T}_{d-1}\mathbf{B}_d\mathbf{T}_d)$.

**Proposition:** The function $f(\mathcal{B}, \mathcal{X}) := \psi(\mathbf{L}_1^\downarrow\mathbf{X}_1\mathbf{W}_1 + \mathbf{L}_1^\uparrow\mathbf{X}_1\mathbf{W}_2)$ is orientation equivariant when $\psi$ is an odd function. This is because an odd $\psi$ commutes with $\mathbf{T}_1$, allowing $\mathbf{T}_1$ to be factored out. This principle generalizes to simplicial message passing architectures.
