# Topological properties and noise robustness
  
[[GDL_SummerSchool_Part1]] (Page 13)

![[assets/slide-13.jpg]]

## Front
Topological properties and noise robustness

## Back
Topological properties are inherently robust to noise because they are invariant under smooth deformations (continuous changes in shape without tearing or gluing). This means their fundamental characteristics (like the number of holes) remain unchanged despite physical distortions. This principle is foundational to Topological Quantum Computers, which aim for noise-resilient computation. For example, a topologist considers a donut and a coffee mug to be the same, as one can be smoothly deformed into the other.
