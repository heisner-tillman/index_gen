# Topological Asymptotic Behavior of Linear GCNs and Simplicial CNs
  
[[GDL_SummerSchool_Part1]] (Page 64)

![[assets/slide-64.jpg]]

## Front
Topological Asymptotic Behavior of Linear GCNs and Simplicial CNs

## Back
The asymptotic behavior of Deep Linear GCNs and their simplicial versions is topological. Specifically:
- **(Linear) GCN:** Features converge to a signal that depends only on the connected components of the graph and their degrees.
- **Linear Simplicial CN:** Features converge to a signal whose energy is concentrated around the holes of the complex.
