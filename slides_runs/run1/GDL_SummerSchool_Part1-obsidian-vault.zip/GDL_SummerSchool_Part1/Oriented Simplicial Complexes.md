# Oriented Simplicial Complexes
  
[[GDL_SummerSchool_Part1]] (Page 37)

![[assets/slide-37.jpg]]

## Front
Oriented Simplicial Complexes

## Back
An oriented simplicial complex is a simplicial complex with a chosen orientation for each of its simplices. An easy way to choose an orientation is to establish a global order for the vertices `[v0, ..., vn]` and then use this order for the vertices of any simplex `σ`.
