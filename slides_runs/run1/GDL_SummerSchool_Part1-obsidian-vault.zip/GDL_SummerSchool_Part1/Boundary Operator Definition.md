# Boundary Operator Definition
  
[[GDL_SummerSchool_Part1]] (Page 41)

![[assets/slide-41.jpg]]

## Front
Boundary Operator Definition

## Back
The boundary operator, denoted as ∂_k, is a linear operator mapping k-chains to (k-1)-chains: ∂_k : C_k(K, R) → C_{k-1}(K, R). It is defined for a simplex (v_0, ..., v_k) as the alternating sum of its faces: ∂_k(v_0, ..., v_k) = Σ_{i=0}^k (-1)^i (v_0, ..., v_i, ..., v_k), where (v_0, ..., v_i, ..., v_k) represents the simplex obtained by dropping the vertex v_i.
