# Oriented Simplex Definition and Examples
  
[[GDL_SummerSchool_Part1]] (Page 33)

![[assets/slide-33.jpg]]

## Front
Oriented Simplex Definition and Examples

## Back
An oriented simplex is a simplex with a specified order of its vertices. This order can be visualized as a walk on the simplex. For a 1-simplex {1,2}, two orientations are (1,2) and (2,1). For a 2-simplex {1,2,3}, two orientations are (1,2,3) (counter-clockwise walk) and (1,3,2) (clockwise walk).
