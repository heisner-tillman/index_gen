# Expressive Power of Topological Message Passing
  
[[GDL_SummerSchool_Part1]] (Page 97)

![[assets/slide-97.jpg]]

## Front
Expressive Power of Topological Message Passing

## Back
A theorem states that topological message passing, when utilizing injective neighborhood aggregators and a sufficient number of layers, achieves expressive power equivalent to that of CWL (e.g., 3WL).

The accompanying bar chart provides empirical evidence, comparing the failure rates of MLP sum (with 4, 5, and 6 layers) and CIN (with 4, 5, and 6 layers) models against a 3WL baseline across various SR (Substructure Recognition) datasets. The results show that many MLP sum and CIN configurations achieve a 0 failure rate, mirroring the 3WL baseline, which supports the theorem's assertion of their equivalent expressive capabilities.
