# How does Poincaré's view connect Topology to Geometric Deep Learning?
  
[[GDL_SummerSchool_Part1]] (Page 17)

![[assets/slide-17.jpg]]

## Front
How does Poincaré's view connect Topology to Geometric Deep Learning?

## Back
Henri Poincaré, in "Analysis Situs", discussed topology as the study of invariants of homeomorphisms, considering it a subfield of Klein's geometry. In this context, Topological Deep Learning can be seen as a subfield of Geometric Deep Learning.
