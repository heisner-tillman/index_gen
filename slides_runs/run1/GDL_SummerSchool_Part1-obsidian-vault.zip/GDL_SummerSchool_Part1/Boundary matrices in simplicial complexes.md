# Boundary matrices in simplicial complexes
  
[[GDL_SummerSchool_Part1]] (Page 52)

![[assets/slide-52.jpg]]

## Front
Boundary matrices in simplicial complexes

## Back
Boundary matrices represent boundary operators, mapping k-simplices to (k-1)-simplices. For a given simplicial complex:
- **B_1 (vertex-edge matrix)**: Rows correspond to vertices, columns to edges. An entry is +1 if the vertex is the head of the edge, -1 if the tail, and 0 otherwise.
- **B_2 (edge-face matrix)**: Rows correspond to edges, columns to faces. An entry is +1 if the edge is part of the face boundary with consistent orientation, -1 if inconsistent, and 0 otherwise.
The slide provides examples of B_1 for vertices v1-v5 and edges e1-e6, and B_2 for edges e1-e6 and faces t1-t2.
