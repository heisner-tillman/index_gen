# Graph-Level Tasks in ML
  
[[GDL_SummerSchool_Part1]] (Page 19)

![[assets/slide-19.jpg]]

## Front
Graph-Level Tasks in ML

## Back
Graph-level tasks in Machine Learning involve processing an entire graph structure, including its nodes and their associated features, to predict a single output or property for the whole graph. An example is predicting the solubility of molecules, where each molecule is represented as a graph.
