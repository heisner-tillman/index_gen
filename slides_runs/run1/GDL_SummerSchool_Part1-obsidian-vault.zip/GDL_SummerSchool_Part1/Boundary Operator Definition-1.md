# Boundary Operator Definition
  
[[GDL_SummerSchool_Part1]] (Page 42)

![[assets/slide-42.jpg]]

## Front
Boundary Operator Definition

## Back
The boundary operator `∂_k` is a linear operator mapping `k`-simplices to `(k-1)`-simplices. It is defined as:
`∂_k(v_0, ..., v_k) = Σ_{i=0}^k (-1)^i (v_0, ..., v̂_i, ..., v_k)`
where `(v_0, ..., v̂_i, ..., v_k)` denotes the simplex obtained by dropping vertex `v_i`.

Visually, for a 2-simplex (triangle `v_0v_1v_2`), `∂` maps it to its boundary (the cycle of edges `v_0v_1 + v_1v_2 + v_2v_0`). Applying `∂` again to this boundary results in `∅` (the empty set), illustrating `∂∂ = 0`.
