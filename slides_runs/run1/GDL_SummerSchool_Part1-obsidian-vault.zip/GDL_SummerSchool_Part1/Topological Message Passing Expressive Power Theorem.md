# Topological Message Passing Expressive Power Theorem
  
[[GDL_SummerSchool_Part1]] (Page 96)

![[assets/slide-96.jpg]]

## Front
Topological Message Passing Expressive Power Theorem

## Back
Topological message passing, when implemented with injective neighborhood aggregators and a sufficient number of layers, achieves the same expressive power as CWL.
