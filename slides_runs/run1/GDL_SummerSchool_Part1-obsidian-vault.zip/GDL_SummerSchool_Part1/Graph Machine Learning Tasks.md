# Graph Machine Learning Tasks
  
[[GDL_SummerSchool_Part1]] (Page 20)

![[assets/slide-20.jpg]]

## Front
Graph Machine Learning Tasks

## Back
Graph Machine Learning (ML) typically involves two types of tasks:
- **Graph-Level Tasks**: These tasks focus on making predictions or classifications for the entire graph structure. An example is predicting the solubility of molecules, where each molecule is represented as a graph.
- **Node-Level Tasks**: These tasks involve making predictions or classifications for individual nodes within a graph. An example is fraud detection, where nodes (e.g., transactions or users) are classified as fraudulent or legitimate.
