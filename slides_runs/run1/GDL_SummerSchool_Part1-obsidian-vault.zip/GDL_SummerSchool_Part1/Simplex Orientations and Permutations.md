# Simplex Orientations and Permutations
  
[[GDL_SummerSchool_Part1]] (Page 35)

![[assets/slide-35.jpg]]

## Front
Simplex Orientations and Permutations

## Back
For k-simplices (k > 0), there are two distinct orientations. These orientations are defined by equivalence classes of permutations of their vertices. One class corresponds to even permutations (e.g., {(1,2,3), (2,3,1), (3,1,2)} for a triangle), representing one orientation (e.g., counter-clockwise). The other class corresponds to odd permutations (e.g., {(1,3,2), (2,1,3), (3,2,1)}), representing the opposite orientation (e.g., clockwise).
