# Why Cell Complexes?
  
[[GDL_SummerSchool_Part1]] (Page 85)

![[assets/slide-85.jpg]]

## Front
Why Cell Complexes?

## Back
Cell complexes are introduced because the subset inclusion property of simplicial complexes can be restrictive. They allow us to still exploit the valuable topological tools that come with such structures, despite the limitations of simplicial complexes.
