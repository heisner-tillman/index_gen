# Message Passing Neural Networks (MPNNs)
  
[[GDL_SummerSchool_Part1]] (Page 21)

![[assets/slide-21.jpg]]

## Front
Message Passing Neural Networks (MPNNs)

## Back
Most Graph Neural Networks (GNNs) can be understood as message passing, involving two main steps for each node 'v' at iteration 'k':
- **Message Aggregation (`m_v^k`):** Messages are aggregated from neighboring nodes `u` (represented by their previous embeddings `h_u^{k-1}`) using an `AGGREGATE` function: `m_v^k := AGGREGATE({h_u^{k-1} | u ∈ N(v)})`.
- **Node Update (`h_v^k`):** The node's embedding is updated by combining its previous embedding `h_v^{k-1}` with the aggregated message `m_v^k` using a `COMBINE` function: `h_v^k := COMBINE(h_v^{k-1}, m_v^k)`.
The diagram visually depicts messages flowing from neighbors to a central node.
