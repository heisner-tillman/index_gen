# What is a topological hole?
  
[[GDL_SummerSchool_Part1]] (Page 50)

![[assets/slide-50.jpg]]

## Front
What is a topological hole?

## Back
A topological hole is a cycle that is not the boundary of a higher-dimensional chain.
*   Both `c1` and `c2` are 1-cycles (∂₁c₁ = ∂₁c₂ = 0).
*   `c1` (not a hole) is the boundary of a 2-chain (c₁ ∈ im ∂₂), meaning the enclosed region is 'filled'.
*   `c2` (a hole) is a cycle but *not* the boundary of a 2-chain, meaning the enclosed region is 'empty'.
