# Simplicial Convolutions: Definition & Mechanism
  
[[GDL_SummerSchool_Part1]] (Page 67)

![[assets/slide-67.jpg]]

## Front
Simplicial Convolutions: Definition & Mechanism

## Back
Simplicial convolutions are defined using a Laplacian. All such convolutions can be understood as a form of message passing. This concept is explored in various research, including works on Simplicial Neural Networks, Simplicial 2-Complex Convolutional Neural Networks, and Simplicial Attention Networks.
