# Simplicial CNNs: Convergence Theorem
  
[[GDL_SummerSchool_Part1]] (Page 62)

![[assets/slide-62.jpg]]

## Front
Simplicial CNNs: Convergence Theorem

## Back
- **Model**: Simplicial equivalent of GCN, Y := σ((I - Δ0)XW), where Δk = αLk is the normalised Hodge Laplacian.
- **Key Definitions**: λ* = maxλi≠0(1 - λi)^2 (based on eigenvalues λi of Δk), σ = id (identity activation), and Dirichlet energy E(X) = trace(X^T Δk X).
- **Theorem**: E(Y) ≤ λ* ||W^T||^2 E(X).
- **Convergence**: If α (scaling factor for Laplacian) is sufficiently low, the model converges exponentially fast to the kernel of Δk.
