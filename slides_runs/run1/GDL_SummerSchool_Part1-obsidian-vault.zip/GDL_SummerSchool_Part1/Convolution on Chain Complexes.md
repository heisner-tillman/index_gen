# Convolution on Chain Complexes
  
[[GDL_SummerSchool_Part1]] (Page 80)

![[assets/slide-80.jpg]]

## Front
Convolution on Chain Complexes

## Back
A chain complex is a sequence of vector spaces (e.g., `C_k(K,R)`) connected by boundary maps (`∂_k`). Convolutions can be applied to these complexes, with boundary matrices ensuring communication across different dimensions. The output `Y` is calculated using the formula: `Y = ψ(L_1↓ X_1 W_1 + L_1↑ X_1 W_2 + B_1ᵀ X_0 W_3 + B_2 X_2 W_4 + X_1 W_5)`, where `ψ` is an activation function, `L` denotes Laplacians (down/up), `B` represents boundary matrices, `X` are input features, and `W` are learnable weights.
