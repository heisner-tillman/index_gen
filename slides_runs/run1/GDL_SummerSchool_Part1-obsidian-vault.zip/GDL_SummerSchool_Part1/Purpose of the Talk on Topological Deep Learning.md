# Purpose of the Talk on Topological Deep Learning
  
[[GDL_SummerSchool_Part1]] (Page 3)

![[assets/slide-3.jpg]]

## Front
Purpose of the Talk on Topological Deep Learning

## Back
This talk aims to describe the vision for a research program on Topological Deep Learning, stemming from a 2020 PhD proposal. The term has been used in works by Carlsson (2021), Hajiji and Istvan (2021), and Rieck (2022).
