# Topological implications of GCN and Simplicial CN asymptotic behavior
  
[[GDL_SummerSchool_Part1]] (Page 65)

![[assets/slide-65.jpg]]

## Front
Topological implications of GCN and Simplicial CN asymptotic behavior

## Back
The asymptotic behavior of Deep Linear GCNs and their simplicial versions is topological:
- **(Linear) GCNs**: Features converge to a signal dependent on the graph's connected components and their degrees.
- **Linear Simplicial CNs**: Features converge to a signal with energy concentrated around the holes of the complex.
- The dimension of the subspace where the model converges remains invariant under homeomorphisms, as $\beta_k$ (Betti number) is a topological invariant.
