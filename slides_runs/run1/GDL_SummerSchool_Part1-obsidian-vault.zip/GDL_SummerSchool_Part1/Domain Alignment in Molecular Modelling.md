# Domain Alignment in Molecular Modelling
  
[[GDL_SummerSchool_Part1]] (Page 102)

![[assets/slide-102.jpg]]

## Front
Domain Alignment in Molecular Modelling

## Back
Domain alignment refers to the spatial arrangement of molecular structures, which is particularly useful in applications like molecular modelling. The slide illustrates this with a detailed chemical structure (likely a purine derivative like caffeine) and a simplified skeletal representation of fused rings (a hexagon and a pentagon), implying how such structural information is used for alignment and analysis in molecular modeling.
