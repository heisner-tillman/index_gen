# Long-range interactions experiment: GIN vs CIN
  
[[GDL_SummerSchool_Part1]] (Page 101)

![[assets/slide-101.jpg]]

## Front
Long-range interactions experiment: GIN vs CIN

## Back
An experiment validated long-range interactions by requiring a model to transfer a value from one side of a ring graph to the other. The results compare GIN and CIN models:
- CIN consistently maintains high accuracy (near 1.0) across all tested ring sizes (10 to 30).
- GIN's accuracy significantly degrades with increasing ring size, dropping below 0.2 for ring sizes 24 and above.
- This indicates CIN's superior capability in handling long-range dependencies for this task.
