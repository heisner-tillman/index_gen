# Bottom-up approach for non-Euclidean data
  
[[GDL_SummerSchool_Part1]] (Page 12)

![[assets/slide-12.jpg]]

## Front
Bottom-up approach for non-Euclidean data

## Back
The topological perspective provides a bottom-up approach for learning from non-Euclidean data. This hierarchy progresses from fundamental 'Sets' to 'Topological Spaces', 'Topological Manifolds', 'Smooth Manifolds', and finally 'Riemannian Manifolds'. This method allows for the recovery of higher-level structures, even in ill-behaved spaces like graphs.
