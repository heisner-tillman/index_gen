# Boundary of a Boundary is Zero
  
[[GDL_SummerSchool_Part1]] (Page 47)

![[assets/slide-47.jpg]]

## Front
Boundary of a Boundary is Zero

## Back
The proposition states that the boundary of a boundary is zero: $\partial_{k-1} \circ \partial_k = 0$. This is equivalent to the image of the k-th boundary operator being a subset of the kernel of the (k-1)-th boundary operator (im $\partial_k \subseteq$ ker $\partial_{k-1}$). The proof begins by applying $\partial_{k-1}$ to the result of $\partial_k$ on a k-simplex $(v_0, \dots, v_k)$, which is defined as a sum of alternating signed (k-1)-simplices (Eq. 4). The subsequent step (Eq. 5) expands this further, showing two sums that are expected to cancel out, thus proving the proposition.
