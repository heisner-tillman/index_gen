# Simplicial Complex Definition (Part 1)
  
[[GDL_SummerSchool_Part1]] (Page 28)

![[assets/slide-28.jpg]]

## Front
Simplicial Complex Definition (Part 1)

## Back
A simplicial complex K is a collection of non-empty subsets of a non-empty vertex set V, called simplices. The first condition for K is that it must contain all the singleton subsets of V.
