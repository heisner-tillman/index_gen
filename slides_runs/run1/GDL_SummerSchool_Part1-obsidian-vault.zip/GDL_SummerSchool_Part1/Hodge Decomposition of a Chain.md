# Hodge Decomposition of a Chain
  
[[GDL_SummerSchool_Part1]] (Page 66)

![[assets/slide-66.jpg]]

## Front
Hodge Decomposition of a Chain

## Back
The Hodge Decomposition Theorem states that a chain `C_k(K, R)` can be uniquely decomposed into three orthogonal components:
*   **Rotational part**: `im ∂_k^T` (e.g., `im ∂_2` in the diagram, characterized by swirling patterns).
*   **Harmonic part**: `ker L_k` (e.g., `ker L_1` in the diagram, representing smooth, non-rotational, non-gradient flow).
*   **Gradient part**: `im ∂_{k+1}` (e.g., `im ∂_1^T` in the diagram, showing flow originating from sources and ending at sinks).
This decomposition is illustrated on a torus, breaking down a complex flow into these fundamental parts.
