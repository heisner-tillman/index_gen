# What is a Simplicial Complex?
  
[[GDL_SummerSchool_Part1]] (Page 27)

![[assets/slide-27.jpg]]

## Front
What is a Simplicial Complex?

## Back
A simplicial complex K is defined as a collection of non-empty subsets of a non-empty vertex set V. These subsets are referred to as simplices. (The definition is incomplete on this slide, ending with "such that:")
