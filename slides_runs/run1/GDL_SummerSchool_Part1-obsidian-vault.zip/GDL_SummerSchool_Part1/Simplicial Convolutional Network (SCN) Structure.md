# Simplicial Convolutional Network (SCN) Structure
  
[[GDL_SummerSchool_Part1]] (Page 68)

![[assets/slide-68.jpg]]

## Front
Simplicial Convolutional Network (SCN) Structure

## Back
SCNs define convolutions using a Laplacian, seen as message passing. Key components:
- **Inputs**: X0, X1, X2 are matrices for 0, 1, and 2-chains respectively.
- **Weights**: W_i are learnable parameters.
- **Operators**: L_down, L_up, B_transpose, B_2 (representing lower/upper adjacency, boundary/coboundary) can be replaced by attention matrices.
- **Output (Y)**: Y = psi(L_down X1 W1 + L_up X1 W2 + B_transpose X0 W3 + B2 X2 W4 + X1 W5), combining different simplicial operations (lower/upper adjacency, boundary/coboundary) on various chain inputs with learned weights.
