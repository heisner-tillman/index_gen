# What is a topological hole?
  
[[GDL_SummerSchool_Part1]] (Page 48)

![[assets/slide-48.jpg]]

## Front
What is a topological hole?

## Back
A topological hole is an empty region within a triangulated space, bounded by a 1-cochain (a cycle of edges). The key difference between two 1-cochains (c1 and c2) is whether the region they enclose is filled or empty:
*   **c1 (not a hole):** The 1-cochain encloses a region that is filled with triangles.
*   **c2 (a hole):** The 1-cochain encloses an empty region.
