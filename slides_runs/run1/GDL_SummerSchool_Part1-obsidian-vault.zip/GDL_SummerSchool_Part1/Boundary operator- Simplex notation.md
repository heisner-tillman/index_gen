# Boundary operator: Simplex notation
  
[[GDL_SummerSchool_Part1]] (Page 40)

![[assets/slide-40.jpg]]

## Front
Boundary operator: Simplex notation

## Back
The notation $\sigma_{-i} := (v_0, \dots, \hat{v}_i, \dots, v_k)$ denotes a simplex formed by removing the vertex $v_i$ from the original simplex $(v_0, \dots, v_k)$. This is a fundamental concept for defining the boundary operator.
