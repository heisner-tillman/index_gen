# Orientation Equivariance in Boundary Matrices
  
[[GDL_SummerSchool_Part1]] (Page 75)

![[assets/slide-75.jpg]]

## Front
Orientation Equivariance in Boundary Matrices

## Back
If a simplex changes its orientation, it flips its relative orientation with respect to adjacent neighbors. This is reflected by flipping signs in the corresponding rows and columns of boundary matrices.

For example, if a 2-simplex (triangle `t2`) flips its orientation:
- The column corresponding to `t2` in the `B2` matrix (mapping 2-simplices to 1-simplices) has all its signs flipped.
- The shared 1-simplex (edge `e6`) also effectively flips its orientation.
- This flip in `e6`'s orientation causes:
  - The column corresponding to `e6` in the `B1` matrix (mapping 1-simplices to 0-simplices) to have its signs flipped.
  - The entry for `e6` in the boundary of the adjacent 2-simplex (`t1`) in the `B2` matrix to have its sign flipped.
