# Molecular Property Prediction Method Comparison
  
[[GDL_SummerSchool_Part1]] (Page 103)

![[assets/slide-103.jpg]]

## Front
Molecular Property Prediction Method Comparison

## Back
This table compares various methods for molecular property prediction across ZINC (MAE), ZINC-FULL (MAE), and Mol-HIV (ROC-AUC) datasets. Lower MAE and higher ROC-AUC indicate better performance. The 'CIN (Ours)' method consistently demonstrates superior performance:
- ZINC (No Edge Feat.): 0.115 ± 0.003
- ZINC (With Edge Feat.): 0.079 ± 0.006
- ZINC-FULL (All methods): 0.022 ± 0.002
- Mol-HIV (All methods): 80.94 ± 0.57
Other methods include GCN, GAT, GatedGCN, GIN, PNA, DGN, HIMP, and GSN, with CIN (Ours) achieving the best results.
