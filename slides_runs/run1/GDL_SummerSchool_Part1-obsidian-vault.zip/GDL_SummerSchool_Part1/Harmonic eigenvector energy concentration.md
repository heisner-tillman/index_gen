# Harmonic eigenvector energy concentration
  
[[GDL_SummerSchool_Part1]] (Page 57)

![[assets/slide-57.jpg]]

## Front
Harmonic eigenvector energy concentration

## Back
Plotting the harmonic eigenvector of L1 reveals that its energy is concentrated around the hole of the complex. This observation prompts the question: 'What is going on?', suggesting a deeper mathematical or topological explanation for this phenomenon.
