# Orientation Equivariance
  
[[GDL_SummerSchool_Part1]] (Page 77)

![[assets/slide-77.jpg]]

## Front
Orientation Equivariance

## Back
A function `f: Ck(K,R)F¹ → Ck(K,R)F²` is orientation equivariant if `f(TB, TkX) = Tkf(B, X)`, where `T = (T₀, ..., Td)` is a tuple of diagonal matrices with `{\pm 1}` values (`T₀ = I`), and `TB = (T₀B₁T₁, ..., Td-₁BdTd)`.

**Proposition:** The function `f(B, X) := ψ(L₁↓X₁W₁ + L₁↑X₁W₂)` is orientation equivariant when `ψ` is an odd function.

**Proof Sketch:** The proof involves demonstrating that `ψ(((T₀B₁T₁)^T (T₀B₁T₁))T₁X₁W)` simplifies to `ψ(T₁L₁↓X₁W)`, utilizing the property that an odd function `ψ` commutes with `T₁`.
