# What is orientation equivariance and its implication for function f?
  
[[GDL_SummerSchool_Part1]] (Page 74)

![[assets/slide-74.jpg]]

## Front
What is orientation equivariance and its implication for function f?

## Back
Orientation equivariance implies that a model's output should change predictably (e.g., by a sign flip) when the input's orientation is reversed. This is illustrated by a commutative diagram:

*   **Top Path:** An input `3` (with orientation `v1 -> v2`) is transformed by `f` to `f(3)`. Applying an orientation change `σ` to the input `3` results in `-3` (with orientation `v2 -> v1`).
*   **Bottom Path:** The output `f(3)` (with orientation `v1 -> v2`) is transformed by `σ` to `-f(3)` (with orientation `v2 -> v1`).

For the system to be orientation equivariant, the result of applying `f` then `σ` must be the same as applying `σ` then `f`. This means:

`σ(f(3)) = f(σ(3))`

From the diagram, `σ(3) = -3` and `σ(f(3)) = -f(3)`. Therefore, for orientation equivariance, the function `f` must satisfy:

`-f(3) = f(-3)`

This is the definition of an **odd function** (`f(-x) = -f(x)`).
