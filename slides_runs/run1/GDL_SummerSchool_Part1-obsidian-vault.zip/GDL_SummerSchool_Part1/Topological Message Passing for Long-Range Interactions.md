# Topological Message Passing for Long-Range Interactions
  
[[GDL_SummerSchool_Part1]] (Page 98)

![[assets/slide-98.jpg]]

## Front
Topological Message Passing for Long-Range Interactions

## Back
Topological message passing, utilizing the neighborhood structure induced by a cell complex, facilitates long-range interactions with a reduced number of computational steps. Unlike regular message passing on a graph, which requires multiple sequential hops between adjacent nodes for distant communication, topological message passing leverages higher-order connections to create 'shortcuts', thereby making communication between distant nodes more efficient.
