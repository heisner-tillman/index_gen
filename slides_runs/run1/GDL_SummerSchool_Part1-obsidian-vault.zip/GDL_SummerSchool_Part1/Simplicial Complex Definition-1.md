# Simplicial Complex Definition
  
[[GDL_SummerSchool_Part1]] (Page 30)

![[assets/slide-30.jpg]]

## Front
Simplicial Complex Definition

## Back
A simplicial complex K is a collection of non-empty subsets (called simplices) of a non-empty vertex set V, such that:
1. K contains all singleton subsets of V.
2. K is closed under taking subsets (if a simplex is in K, all its non-empty subsets are also in K).

Example: For vertices {1, 2, 3, 4}, a complex could be {{1}, {2}, {3}, {4}, {1, 2}, {1, 3}, {2, 4}, {3, 4}}.
