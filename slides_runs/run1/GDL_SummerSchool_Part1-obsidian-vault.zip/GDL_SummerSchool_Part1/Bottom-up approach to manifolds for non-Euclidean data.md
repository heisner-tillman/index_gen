# Bottom-up approach to manifolds for non-Euclidean data
  
[[GDL_SummerSchool_Part1]] (Page 11)

![[assets/slide-11.jpg]]

## Front
Bottom-up approach to manifolds for non-Euclidean data

## Back
The topological perspective provides a bottom-up approach for learning from non-Euclidean data, building complexity through a hierarchy of structures:
*   **Sets**: The fundamental collection of elements.
*   **Topological Spaces**: Sets endowed with a topology (open sets).
*   **Topological Manifolds**: Topological spaces that locally resemble Euclidean space.
*   **Smooth Manifolds**: Topological manifolds with a differentiable structure.
*   **Riemannian Manifolds**: Smooth manifolds equipped with a Riemannian metric, allowing for measurement of distances and angles.
