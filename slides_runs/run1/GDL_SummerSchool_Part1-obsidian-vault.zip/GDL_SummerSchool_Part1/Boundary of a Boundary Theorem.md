# Boundary of a Boundary Theorem
  
[[GDL_SummerSchool_Part1]] (Page 46)

![[assets/slide-46.jpg]]

## Front
Boundary of a Boundary Theorem

## Back
The proposition states that the boundary of a boundary is zero, expressed as $\partial_{k-1} \circ \partial_k = 0$. This condition is equivalent to the image of the k-th boundary operator being a subset of the kernel of the (k-1)-th boundary operator (im $\partial_k \subseteq$ ker $\partial_{k-1}$).
