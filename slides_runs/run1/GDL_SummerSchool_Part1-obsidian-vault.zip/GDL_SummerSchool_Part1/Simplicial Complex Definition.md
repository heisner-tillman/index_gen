# Simplicial Complex Definition
  
[[GDL_SummerSchool_Part1]] (Page 29)

![[assets/slide-29.jpg]]

## Front
Simplicial Complex Definition

## Back
A simplicial complex K is a collection of non-empty subsets of a vertex set V (called simplices) such that:
1. K contains all singleton subsets of V.
2. K is closed under taking subsets (if a set is in K, all its non-empty subsets are also in K).
