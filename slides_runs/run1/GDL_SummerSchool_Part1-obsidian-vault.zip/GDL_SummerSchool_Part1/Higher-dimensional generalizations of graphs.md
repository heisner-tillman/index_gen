# Higher-dimensional generalizations of graphs
  
[[GDL_SummerSchool_Part1]] (Page 24)

![[assets/slide-24.jpg]]

## Front
Higher-dimensional generalizations of graphs

## Back
Graphs are 1-dimensional combinatorial topological spaces. Higher-dimensional generalizations include:
*   **Simplicial Complex:** Built from simplices (points, line segments, triangles, etc.), where the intersection of any two simplices is also a simplex.
*   **Cell Complex:** A more general structure built from d-dimensional cells (points, line segments, polygons, polyhedra, etc.), which are not restricted to be simplices.
These structures form a hierarchy of combinatorial topological spaces, addressing limitations of graphs related to their underlying space.
