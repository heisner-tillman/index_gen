# Topological Message Passing: Message Types
  
[[GDL_SummerSchool_Part1]] (Page 93)

![[assets/slide-93.jpg]]

## Front
Topological Message Passing: Message Types

## Back
In Topological Message Passing, cells receive two types of messages:
- **Boundary Messages (orange arrows):** Received by cells like σ and τ.
  - Equation: `m_B^(t+1)(σ) = AGG_τ∈B(σ) (M_B(h_σ^t, h_τ^t))`
- **Upper Messages (blue arrows):** Received by cells like τ and δ.
  - Equation: `m_↑^(t+1)(σ) = AGG_τ∈N_↑(σ), δ∈C(σ,τ) (M_↑(h_σ^t, h_τ^t, h_δ^t))`
