# What defines a Topological Space?
  
[[GDL_SummerSchool_Part1]] (Page 15)

![[assets/slide-15.jpg]]

## Front
What defines a Topological Space?

## Back
A topological space is a set X together with a collection T of subsets of X (called open sets) satisfying these axioms:
1. The empty set (∅) and the set X itself belong to T.
2. Any finite intersection of open sets in T is also an open set.
3. Any arbitrary union of open sets in T is also an open set.
These open sets provide a neighborhood structure for the points of X.
