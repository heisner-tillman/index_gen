# What is the boundary operator in homology?
  
[[GDL_SummerSchool_Part1]] (Page 44)

![[assets/slide-44.jpg]]

## Front
What is the boundary operator in homology?

## Back
The boundary operator $\partial_k: C_k(K, \mathbb{R}) \to C_{k-1}(K, \mathbb{R})$ is a linear operator that maps a $k$-simplex to a sum of its $(k-1)$-dimensional faces with alternating signs.
*   **Definition:** For a simplex $(v_0, \dots, v_k)$, $\partial_k(v_0, \dots, v_k) = \sum_{i=0}^{k} (-1)^i (v_0, \dots, \hat{v}_i, \dots, v_k)$, where $\hat{v}_i$ means vertex $v_i$ is dropped.
*   **Geometric Interpretation:** It transforms a filled simplex (e.g., a triangle) into its boundary (e.g., a cycle of edges).
*   **Fundamental Property:** Applying the boundary operator twice always results in zero, i.e., $\partial\partial = 0$. This means the boundary of a boundary is empty.
