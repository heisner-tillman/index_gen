# Expressive Power of CWL
  
[[GDL_SummerSchool_Part1]] (Page 90)

![[assets/slide-90.jpg]]

## Front
Expressive Power of CWL

## Back
The slide defines `k-CL`, `k-IC`, and `k-C` as "lifting" maps that attach cells to cliques, induced cycles, and simple cycles (respectively) of size at most `k`. A theorem states that for `k ">= 3`, `CWL(k-CL)`, `CWL(k-IC)`, and `CWL(k-C)` are *strictly more powerful* than the standard WL algorithm. The visual examples demonstrate pairs of graphs that WL cannot distinguish, but CWL can.
