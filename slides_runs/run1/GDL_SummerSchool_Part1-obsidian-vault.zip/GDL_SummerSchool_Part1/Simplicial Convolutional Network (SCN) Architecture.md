# Simplicial Convolutional Network (SCN) Architecture
  
[[GDL_SummerSchool_Part1]] (Page 69)

![[assets/slide-69.jpg]]

## Front
Simplicial Convolutional Network (SCN) Architecture

## Back
SCNs define convolutions using a Laplacian, interpretable as message passing. Input features $X_0, X_1, X_2$ represent 0, 1, and 2-chains, respectively. The output $Y$ is computed as $Y = \psi(L_1^\downarrow X_1 W_1 + L_1^\uparrow X_1 W_2 + B_1^T X_0 W_3 + B_2 X_2 W_4 + X_1 W_5)$, where $L_1^\downarrow$, $L_1^\uparrow$, $B_1^T$, and $B_2$ are lower adjacency, upper adjacency, boundary adjacency, and coboundary adjacency operators. These operators can be replaced by matrices with the same sparsity pattern (e.g., attention matrices). This factorization is linked to the Hodge decomposition.
