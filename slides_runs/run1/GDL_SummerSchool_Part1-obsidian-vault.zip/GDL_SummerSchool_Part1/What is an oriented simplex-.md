# What is an oriented simplex?
  
[[GDL_SummerSchool_Part1]] (Page 32)

![[assets/slide-32.jpg]]

## Front
What is an oriented simplex?

## Back
An oriented simplex is a simplex with a specified order of its vertices. It can be visualized as a walk on the simplex following the specified vertex order. For a 1-simplex {1,2}, the two possible orientations are (1,2) and (2,1), representing directed edges from 1 to 2 and 2 to 1, respectively.
