# Long-range interactions: Ring experiment
  
[[GDL_SummerSchool_Part1]] (Page 100)

![[assets/slide-100.jpg]]

## Front
Long-range interactions: Ring experiment

## Back
An experiment to validate the benefits of long-range interactions involves a model transferring a value from one side of a ring-shaped network of nodes to the other. A green node marks the start, and a red node marks the destination, with intermediate steps shown by arrows.
