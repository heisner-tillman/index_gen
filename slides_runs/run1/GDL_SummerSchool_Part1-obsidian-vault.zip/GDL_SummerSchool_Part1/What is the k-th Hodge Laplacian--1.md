# What is the k-th Hodge Laplacian?
  
[[GDL_SummerSchool_Part1]] (Page 56)

![[assets/slide-56.jpg]]

## Front
What is the k-th Hodge Laplacian?

## Back
The k-th Hodge Laplacian, `L_k`, is defined as `L_k = L_k^down + L_k^up = B_k^T B_k + B_{k+1} B_{k+1}^T`. Its matrix elements `L_k^down(i,j)` are:
*   `k+1` if `i=j`
*   `+/-1` if `i!=j` and `sigma_i, sigma_j` share a `(k-1)`-simplex (`sigma_i V sigma_j`)
*   `0` otherwise

And `L_k^up(i,j)` are:
*   `deg^up(sigma_i)` if `i=j`
*   `+/-1` if `i!=j` and `sigma_i, sigma_j` are on the boundary of the same `(k+1)`-simplex (`sigma_i ^ sigma_j`)
*   `0` otherwise

Importantly, `L_0` is equivalent to the usual graph Laplacian, `D - A`.
