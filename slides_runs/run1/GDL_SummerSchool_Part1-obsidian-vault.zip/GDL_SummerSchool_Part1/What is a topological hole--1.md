# What is a topological hole?
  
[[GDL_SummerSchool_Part1]] (Page 49)

![[assets/slide-49.jpg]]

## Front
What is a topological hole?

## Back
A topological hole is a 1-cycle (a closed loop) that does not bound a 2-chain (a filled region) within the given space. The slide illustrates two 1-cycles:
- **c1 (left):** Not a hole, as the triangular region it encloses is filled (it bounds a 2-chain).
- **c2 (right):** Is a hole, as the pentagonal region it encloses is empty (it does not bound a 2-chain).
