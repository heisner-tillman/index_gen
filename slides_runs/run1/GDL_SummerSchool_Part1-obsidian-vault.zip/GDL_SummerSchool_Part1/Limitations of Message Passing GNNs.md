# Limitations of Message Passing GNNs
  
[[GDL_SummerSchool_Part1]] (Page 22)

![[assets/slide-22.jpg]]

## Front
Limitations of Message Passing GNNs

## Back
Message Passing Graph Neural Networks (GNNs) face several limitations:
-   **Higher-order interactions:** Struggle to capture complex relationships beyond pairwise connections.
-   **Higher-order structures:** Limited in distinguishing intricate structural patterns.
-   **Higher-order features:** Difficulty in incorporating features that describe groups of nodes or edges.
-   **Expressive power:** Bounded by the 1-Weisfeiler-Leman (WL) test, meaning they cannot differentiate certain non-isomorphic graphs that higher-order WL tests (e.g., 3-WL) can.
-   **Long-range interactions:** Inefficient at propagating information over many hops, leading to issues like over-smoothing or vanishing gradients.
