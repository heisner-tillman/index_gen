# Geometric Deep Learning: Structured Data
  
[[GDL_SummerSchool_Part1]] (Page 5)

![[assets/slide-5.jpg]]

## Front
Geometric Deep Learning: Structured Data

## Back
Geometric Deep Learning applies deep learning to data residing on non-Euclidean, structured domains such as molecules, meshes, and manifolds. This approach is essential because much real-world data inherently possesses geometric structure, as illustrated by applications in protein structure prediction and bioactive molecule design.
