# CWL Edge Color Refinement
  
[[GDL_SummerSchool_Part1]] (Page 89)

![[assets/slide-89.jpg]]

## Front
CWL Edge Color Refinement

## Back
The Cellular Weisfeiler-Lehman (CWL) test generalizes the WL algorithm for graphs to cellular complexes. For an edge, a color refinement step involves computing a `HASH` function that incorporates:
- The edge's current color.
- Its `Boundary`: colors of its incident 0-cells (vertices).
- Its `Coboundary`: colors of the higher-dimensional cells (e.g., 2-cells/triangles) it is part of.
- Its `Upper adjacency`: colors of adjacent higher-dimensional cells.
- Its `Lower adjacency`: colors of adjacent lower-dimensional cells.
This iterative process is applied to all cells in the complex until colors converge.
