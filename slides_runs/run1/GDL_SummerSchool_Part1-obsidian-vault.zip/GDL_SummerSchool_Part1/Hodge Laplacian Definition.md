# Hodge Laplacian Definition
  
[[GDL_SummerSchool_Part1]] (Page 54)

![[assets/slide-54.jpg]]

## Front
Hodge Laplacian Definition

## Back
The k-th Hodge Laplacian, denoted as $L_k$, is a linear operator mapping from $C_k(K, \mathbb{R})$ to $C_k(K, \mathbb{R})$. It is defined by the formula:
$L_k = L_k^{\downarrow} + L_k^{\uparrow} = B_k^T B_k + B_{k+1} B_{k+1}^T$

Additionally, the notation $\sigma_i \lor \sigma_j$ indicates that $\sigma_i$ and $\sigma_j$ share a $(k-1)$-simplex. The notation $\sigma_i \land \sigma_j$ indicates that $\sigma_i$ and $\sigma_j$ are on the boundary of the same $(k+1)$-simplex.
