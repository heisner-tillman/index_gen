# Graphs and natural geometric structure
  
[[GDL_SummerSchool_Part1]] (Page 7)

![[assets/slide-7.jpg]]

## Front
Graphs and natural geometric structure

## Back
Graphs, a prevalent data space in GDL, lack a "natural" geometric structure, unlike traditional geometric objects such as squares or spheres. This slide illustrates various graph types (grid, complex polyhedral, molecular) and contrasts them with standard geometric shapes, posing the question of how to define or understand the geometry of graphs.
