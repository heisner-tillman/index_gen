# What is a topological hole?
  
[[GDL_SummerSchool_Part1]] (Page 51)

![[assets/slide-51.jpg]]

## Front
What is a topological hole?

## Back
A topological hole is a cycle that does not bound a higher-dimensional chain. For two 1-chains, c1 and c2:
- Both are cycles (∂1c1 = ∂1c2 = 0).
- c1 is *not* a hole because it is the boundary of a 2-chain (c1 ∈ im ∂2).
- c2 *is* a hole because it is a cycle but does *not* bound a 2-chain.
This concept is formalized by the k-th Homology group: Hk(K) := ker ∂k / im ∂k+1, where ker ∂k represents k-cycles and im ∂k+1 represents k-boundaries.
