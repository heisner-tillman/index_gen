# Topological Message Passing Mechanism
  
[[GDL_SummerSchool_Part1]] (Page 94)

![[assets/slide-94.jpg]]

## Front
Topological Message Passing Mechanism

## Back
Topological Message Passing involves cells exchanging and aggregating information based on their topological relationships. Cells receive two types of messages:
*   **Boundary Messages (`m_B^{t+1}(\sigma)`):** Aggregated from cells `\tau` in the boundary `B(\sigma)`, using a message function `M_B(h_\sigma^t, h_\tau^t)`. (Indicated by orange arrows).
*   **Upper Messages (`m_\uparrow^{t+1}(\sigma)`):** Aggregated from cells `\tau` in `N_\uparrow(\sigma)` and `\delta` in `C(\sigma,\tau)`, using a message function `M_\uparrow(h_\sigma^t, h_\tau^t, h_\delta^t)`. (Indicated by blue arrows).

The cell's state is updated using an update function `U` that takes the current state `h_\sigma^t` and the aggregated boundary and upper messages as input: `h_\sigma^{t+1} = U(h_\sigma^t, m_B(\sigma), m_\uparrow^{t+1}(\sigma))`.
