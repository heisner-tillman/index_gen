# Sparse Adjacencies in Star Graphs
  
[[GDL_SummerSchool_Part1]] (Page 91)

![[assets/slide-91.jpg]]

## Front
Sparse Adjacencies in Star Graphs

## Back
Considering all adjacencies can lead to exploding computational complexity. Even though a star graph is sparse, all its edges are "lower adjacent" to each other (sharing the central node), enabling them to exchange messages.
