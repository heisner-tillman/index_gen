# Topological Message Passing Mechanism
  
[[GDL_SummerSchool_Part1]] (Page 95)

![[assets/slide-95.jpg]]

## Front
Topological Message Passing Mechanism

## Back
Topological Message Passing involves cells receiving two types of messages:
*   **Boundary messages** ($m_B^{t+1}(\sigma)$): Aggregated from cells $\tau$ in the boundary of $\sigma$.
*   **Upper messages** ($m_{\uparrow}^{t+1}(\sigma)$): Aggregated from cells $\tau$ in the upper neighborhood of $\sigma$ and cells $\delta$ in the co-boundary of $\sigma$ and $\tau$.
These messages, along with the current state ($h_{\sigma}^t$), are used by an **update function** $U$ to compute the next state ($h_{\sigma}^{t+1}$). A **readout function** then computes a final representation from the cell states across different dimensions.
