# Permutation Equivariance of f(B, X)
  
[[GDL_SummerSchool_Part1]] (Page 72)

![[assets/slide-72.jpg]]

## Front
Permutation Equivariance of f(B, X)

## Back
A function `f: Ck(K,R)^F1 \to Ck(K,R)^F2` is permutation equivariant if `f(PB, PkX) = Pk f(B, X)`.
*   `B = (B1, ..., Bd)` represents a simplicial complex via its boundary matrices.
*   `PB = (P0B1P1^T, ..., Pd-1BdPd^T)` is the permuted version of `B`, where `P = (P0, ..., Pd)` are permutation matrices.
*   **Proposition:** The function `f(B, X) := \psi(L_1^{\downarrow}X_1W_1 + L_1^{\uparrow}X_1W_2)` is permutation equivariant.
*   **Proof Sketch:** The proof demonstrates that applying permutations to `B` and `X` results in the permutation matrix `Pk` factoring out. For instance, considering lower adjacencies, `(P_0B_1P_1^T)^T (P_0B_1P_1^T) (P_1X_1)W_1` simplifies to `P_1(L_1^{\downarrow}X_1W)`.
