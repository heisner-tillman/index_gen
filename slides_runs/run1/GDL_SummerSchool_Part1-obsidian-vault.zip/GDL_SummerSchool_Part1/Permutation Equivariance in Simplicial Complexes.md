# Permutation Equivariance in Simplicial Complexes
  
[[GDL_SummerSchool_Part1]] (Page 70)

![[assets/slide-70.jpg]]

## Front
Permutation Equivariance in Simplicial Complexes

## Back
A simplicial complex of dimension `d` is defined by its boundary matrices `B = (B1, ..., Bd)`. A tuple of permutation matrices is `P = (P0, ..., Pd)`. The action of `P` on `B` is denoted as `PB = (P0 B1 P1^T, ..., Pd-1 Bd Pd^T)`.
