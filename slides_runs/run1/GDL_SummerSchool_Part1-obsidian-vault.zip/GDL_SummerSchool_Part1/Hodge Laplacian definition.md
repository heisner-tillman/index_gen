# Hodge Laplacian definition
  
[[GDL_SummerSchool_Part1]] (Page 55)

![[assets/slide-55.jpg]]

## Front
Hodge Laplacian definition

## Back
The k-th Hodge Laplacian $L_k: C_k(K,\mathbb{R}) \to C_k(K,\mathbb{R})$ is defined as:

$L_k = L_k^\downarrow + L_k^\uparrow = B_k^T B_k + B_{k+1} B_{k+1}^T$

Where $L_k^\downarrow(i,j)$ is a piecewise function:
- $k+1$ if $i=j$
- $\pm 1$ if $i \neq j$ and $\sigma_i \lor \sigma_j$
- $0$ otherwise

**Notation:**
- $\sigma_i \lor \sigma_j$: $\sigma_i, \sigma_j$ share a $(k-1)$-simplex.
- $\sigma_i \land \sigma_j$: $\sigma_i, \sigma_j$ are on the boundary of the same $(k+1)$-simplex.
