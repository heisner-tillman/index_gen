# What is an Oriented Simplicial Complex?
  
[[GDL_SummerSchool_Part1]] (Page 36)

![[assets/slide-36.jpg]]

## Front
What is an Oriented Simplicial Complex?

## Back
An oriented simplicial complex is a simplicial complex where each of its simplices (vertices, edges, faces) has a chosen orientation. The diagram illustrates an example with oriented 2-simplices (triangles) and 1-simplices (edges) between vertices 0, 1, 2, 3, and 4.
