# What is a Simplicial Complex?
  
[[GDL_SummerSchool_Part1]] (Page 31)

![[assets/slide-31.jpg]]

## Front
What is a Simplicial Complex?

## Back
A simplicial complex K is a collection of non-empty subsets (called simplices) of a non-empty vertex set V, such that:
1. K contains all singleton subsets of V.
2. K is closed under taking subsets (if a simplex is in K, all its non-empty subsets are also in K).

Examples are provided with their corresponding sets of simplices, illustrating these properties.
