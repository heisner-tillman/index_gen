# Topological Obstructions and the Hairy Ball Theorem
  
[[GDL_SummerSchool_Part1]] (Page 8)

![[assets/slide-8.jpg]]

## Front
Topological Obstructions and the Hairy Ball Theorem

## Back
Topological obstructions occur because the structure of the topological layer influences the geometrical layer. This means the topology of a space affects the properties of models operating within it. The Hairy Ball Theorem is a key example, illustrating that it's impossible to comb the hair flat on a sphere without creating at least one 'cowlick' (a point where the vector field is zero).
