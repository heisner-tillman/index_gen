# Sparse Adjacencies and CWL Expressiveness
  
[[GDL_SummerSchool_Part1]] (Page 92)

![[assets/slide-92.jpg]]

## Front
Sparse Adjacencies and CWL Expressiveness

## Back
Considering all adjacencies can lead to computational complexity explosion. Even sparse graphs, like a star graph, have edges that are 'lower adjacent' and exchange messages. A key theorem states that CWL (Cellular Weisfeiler-Leman) without coboundary and using only lower adjacencies is as expressive as CWL with the full set of adjacencies, suggesting that full adjacency information may not always be necessary for expressiveness.
