# Topological Obstructions
  
[[GDL_SummerSchool_Part1]] (Page 9)

![[assets/slide-9.jpg]]

## Front
Topological Obstructions

## Back
Topological obstructions highlight how the underlying topology of a space affects its geometrical properties and the behavior of models. Two key examples are:
- **The Hairy Ball Theorem:** States that it's impossible to comb a sphere's 'hair' (a continuous tangent vector field) flat without creating at least one 'cowlick' (a point where the vector is zero).
- **The Borsuk-Ulam Theorem:** For any continuous map from an n-sphere to n-dimensional Euclidean space, there exists at least one pair of antipodal points that map to the same point.
