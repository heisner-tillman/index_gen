# What are k-chains?
  
[[GDL_SummerSchool_Part1]] (Page 39)

![[assets/slide-39.jpg]]

## Front
What are k-chains?

## Back
A k-chain Ck(K, R) is an element of a vector space with real coefficients, where the basis elements are the oriented k-simplices of K.
*   **1-chain (c1)**: A linear combination of oriented edges (1-simplices) with real coefficients. For example, `c1 = 2.5(0, 1) - (3, 4) + 3.14(1, 3)`, which can also be written as `c1 = 2.5(0, 1) + (4, 3) + 3.14(1, 3)`.
*   **2-chain (c2)**: A linear combination of oriented triangles (2-simplices) with real coefficients. For example, `c2 = 5.0(0, 1, 2) + 4.0(1, 2, 3)`.
