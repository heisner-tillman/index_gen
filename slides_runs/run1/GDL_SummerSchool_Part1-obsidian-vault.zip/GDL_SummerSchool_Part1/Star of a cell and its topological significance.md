# Star of a cell and its topological significance
  
[[GDL_SummerSchool_Part1]] (Page 99)

![[assets/slide-99.jpg]]

## Front
Star of a cell and its topological significance

## Back
The **star of a cell** `σ`, denoted `st σ`, is defined as the union of all cells that have `σ` as a face. These stars of all cells form the basis of a topology for the cell complex.

*   **Graph case (left)**: The open neighborhoods (stars) of two distinct nodes (green and red) do not intersect.
*   **Higher-dimensional cell complex (right)**: The neighborhoods (stars) of the nodes are significantly expanded, encompassing the node, incident edges, and the entire 2D face (polygon) containing the node.
