# What is the k-th Hodge Laplacian?
  
[[GDL_SummerSchool_Part1]] (Page 53)

![[assets/slide-53.jpg]]

## Front
What is the k-th Hodge Laplacian?

## Back
The k-th Hodge Laplacian, denoted L_k, is an operator mapping C_k(K, R) to C_k(K, R). It is defined as the sum of the 'down' and 'up' Laplacians: L_k = L_k^down + L_k^up. The specific formula for L_k is given by L_k = B_k^T B_k + B_{k+1} B_{k+1}^T, where B_k and B_{k+1} are boundary operators. This concept is fundamental in areas like combinatorial Laplace operators and topological signal processing on simplicial complexes.
