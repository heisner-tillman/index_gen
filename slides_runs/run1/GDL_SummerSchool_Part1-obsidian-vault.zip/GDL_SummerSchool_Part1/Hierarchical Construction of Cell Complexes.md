# Hierarchical Construction of Cell Complexes
  
[[GDL_SummerSchool_Part1]] (Page 87)

![[assets/slide-87.jpg]]

## Front
Hierarchical Construction of Cell Complexes

## Back
Cell complexes are constructed hierarchically through these steps:
1.  **Start:** Begin with a set of vertices.
2.  **Add 1D elements:** Glue the boundary of a set of line segments to these existing vertices.
3.  **Add 2D elements:** Glue the boundary of two-dimensional disks to the cycles formed in the graph from the previous step.
