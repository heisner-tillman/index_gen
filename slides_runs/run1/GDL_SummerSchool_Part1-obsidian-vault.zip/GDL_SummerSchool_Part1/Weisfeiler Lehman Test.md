# Weisfeiler Lehman Test
  
[[GDL_SummerSchool_Part1]] (Page 88)

![[assets/slide-88.jpg]]

## Front
Weisfeiler Lehman Test

## Back
The Weisfeiler Lehman (WL) test is a heuristic algorithm for testing graph isomorphism. It works by:
- Performing iterative colour-refinement: Nodes are initially assigned a color, then iteratively re-colored based on their current color and the multiset of colors of their neighbors.
- Generating a 'HASH' (a multiset of node colors) at each step.
- Comparing the final color histograms (distributions) of two graphs after convergence.

**Limitation:** If two non-isomorphic graphs converge to the same color histogram, the WL test is inconclusive and fails to distinguish them.
