# Proposition: Permutation Equivariance of f(B, X)
  
[[GDL_SummerSchool_Part1]] (Page 73)

![[assets/slide-73.jpg]]

## Front
Proposition: Permutation Equivariance of f(B, X)

## Back
A simplicial complex B is defined by boundary matrices (B_1, ..., B_d). A tuple of permutation matrices P = (P_0, ..., P_d) transforms B to PB = (P_0 B_1 P_1^T, ..., P_{d-1} B_d P_d^T). A function f is permutation equivariant if f(PB, P_k X) = P_k f(B, X).

**Proposition:** The function f(B, X) := \psi(L_1^\downarrow X_1 W_1 + L_1^\uparrow X_1 W_2) is permutation equivariant.

**Proof Sketch:**
*   For lower adjacencies: (P_0 B_1 P_1^T)^T (P_0 B_1 P_1^T) (P_1 X_1) W_1 = P_1 B_1^T B_1 X_1 W = P_1 (L_1^\downarrow X_1 W).
*   Upper adjacencies proceed similarly.
*   The nonlinearity \psi commutes with P_1.
