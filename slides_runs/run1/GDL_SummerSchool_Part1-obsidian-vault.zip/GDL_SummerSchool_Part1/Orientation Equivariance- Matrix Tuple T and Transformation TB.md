# Orientation Equivariance: Matrix Tuple T and Transformation TB
  
[[GDL_SummerSchool_Part1]] (Page 76)

![[assets/slide-76.jpg]]

## Front
Orientation Equivariance: Matrix Tuple T and Transformation TB

## Back
In the context of Orientation Equivariance:
- A tuple of matrices `T` is defined as `(T_0, ..., T_d)`.
- Each `T_i` is a diagonal matrix with values from `{+1, -1}`.
- `T_0` is restricted to be the identity matrix (`I`) because vertices always have a positive orientation.
- The transformation `TB` is denoted as `(T_0 B_1 T_1, ..., T_{d-1} B_d T_d)`.
