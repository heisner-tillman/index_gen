# Cell Complex Definition
  
[[GDL_SummerSchool_Part1]] (Page 86)

![[assets/slide-86.jpg]]

## Front
Cell Complex Definition

## Back
A finite (regular) cell complex is a topological space X formed by a finite disjoint union of subspaces called cells. These cells must satisfy two conditions: 1. Each cell is homeomorphic to R^n for some n. 2. The closure of each cell is homeomorphic to a closed ball in R^n. This structure allows for the use of topological tools while being less restrictive than simplicial complexes, as illustrated by homeomorphisms (φ1, φ2, φ3) mapping closed balls to cells of varying dimensions within the complex.
