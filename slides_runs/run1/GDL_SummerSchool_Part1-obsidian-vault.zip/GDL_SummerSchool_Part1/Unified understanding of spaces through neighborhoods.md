# Unified understanding of spaces through neighborhoods
  
[[GDL_SummerSchool_Part1]] (Page 10)

![[assets/slide-10.jpg]]

## Front
Unified understanding of spaces through neighborhoods

## Back
Various types of 'spaces' (illustrated by graphs, grids, polyhedra, and smooth surfaces) can be treated in a unified manner. This is achieved by understanding them through their fundamental 'neighbourhood' or 'open set structure', providing a general framework for analysis.
