# Why is non-linearity crucial in chain complex convolutions?
  
[[GDL_SummerSchool_Part1]] (Page 82)

![[assets/slide-82.jpg]]

## Front
Why is non-linearity crucial in chain complex convolutions?

## Back
Convolutions on chain complexes use boundary maps to ensure communication across different dimensions. The output `Y` is computed as `Y = ψ(L_1↓ X_1 W_1 + L_1↑ X_1 W_2 + B_1^T X_0 W_3 + B_2 X_2 W_4 + X_1 W_5)`. A key proposition states that `ψ` must be non-linear for simplices more than two dimensions apart to communicate. If `ψ` were the identity (linear), 2-chains propagating to the 0-chain level would result in `B_1(B_2 X_2 W_4^1)W_4^2 = (B_1 B_2)X_2 W_4^1 = 0`, due to the property `B_1 B_2 = 0` in chain complexes, thus preventing communication.
