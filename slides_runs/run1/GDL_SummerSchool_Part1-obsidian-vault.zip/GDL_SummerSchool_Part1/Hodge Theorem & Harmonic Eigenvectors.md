# Hodge Theorem & Harmonic Eigenvectors
  
[[GDL_SummerSchool_Part1]] (Page 58)

![[assets/slide-58.jpg]]

## Front
Hodge Theorem & Harmonic Eigenvectors

## Back
The Hodge Theorem states that the kernel of the Laplacian operator Lk (ker Lk) and the k-th homology group Hk(K) are isomorphic vector spaces. This means harmonic eigenvectors (like the one shown for L1) can detect topological features such as holes in a complex, as their energy concentrates around these features.
