# Simplicial Convolutional Networks: Core Definitions
  
[[GDL_SummerSchool_Part1]] (Page 60)

![[assets/slide-60.jpg]]

## Front
Simplicial Convolutional Networks: Core Definitions

## Back
Simplicial Convolutional Networks are defined using:
- **Simplicial complex K**: The fundamental structure.
- **Normalised Hodge Laplacian Δ_k**: Expressed as Δ_k = αL_k, where L_k is the Hodge Laplacian and α > 0. This operator is essential for defining convolutions.
- **k-simplex features X**: Features associated with each k-simplex, represented by a matrix X ∈ R^(n_k × d), where n_k is the number of k-simplices and d is the feature dimension.
