# Hodge Theorem & Betti Numbers
  
[[GDL_SummerSchool_Part1]] (Page 59)

![[assets/slide-59.jpg]]

## Front
Hodge Theorem & Betti Numbers

## Back
The Hodge Theorem states that the kernel of the Laplacian operator (ker Lk) and the k-th homology group (Hk(K)) are isomorphic vector spaces. This means the k-th Betti number (βk), defined as βk = dim(ker Lk) = dim(Hk), counts the number of k-dimensional holes in a complex. For instance, the harmonic eigenvector of L1 concentrates energy around a 1-dimensional hole.
