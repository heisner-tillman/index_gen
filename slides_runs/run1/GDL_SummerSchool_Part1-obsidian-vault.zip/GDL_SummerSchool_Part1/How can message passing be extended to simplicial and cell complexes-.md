# How can message passing be extended to simplicial and cell complexes?
  
[[GDL_SummerSchool_Part1]] (Page 25)

![[assets/slide-25.jpg]]

## Front
How can message passing be extended to simplicial and cell complexes?

## Back
Graphs are 1-dimensional combinatorial topological spaces. Higher-dimensional generalizations include:
- **Simplicial Complexes**: Built from simplices (e.g., points, edges, triangles, tetrahedra).
- **Cell Complexes**: Built from more general d-dimensional cells.
The challenge is to extend message passing techniques, typically used on graphs, to these higher-dimensional structures.
