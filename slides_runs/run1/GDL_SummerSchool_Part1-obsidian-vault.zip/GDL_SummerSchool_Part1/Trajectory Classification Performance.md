# Trajectory Classification Performance
  
[[GDL_SummerSchool_Part1]] (Page 83)

![[assets/slide-83.jpg]]

## Front
Trajectory Classification Performance

## Back
This slide details the application of various methods (GNN L0-inv, MPSN L0-inv, MPSN - ReLU, MPSN - Id, MPSN - Tanh) to trajectory classification. Trajectories are represented as 1-chains, with edge orientations fixed during training and randomly flipped during testing.

Two tasks are evaluated:
- **Synthetic Flow**: Classifying random walks.
  - MPSN - ReLU achieves 100.0% on train, but 50.0% on test.
  - MPSN - Tanh shows the best test performance at 95.2% ± 1.8.
- **Ocean Drifters**: Classifying trajectories around Madagascar.
  - MPSN - Id achieves the highest train accuracy at 94.6% ± 0.9.
  - MPSN L0-inv achieves the best test performance at 71.5% ± 4.1.

Overall, MPSN variants generally outperform GNN L0-inv, with different MPSN architectures excelling in specific tasks or metrics.
