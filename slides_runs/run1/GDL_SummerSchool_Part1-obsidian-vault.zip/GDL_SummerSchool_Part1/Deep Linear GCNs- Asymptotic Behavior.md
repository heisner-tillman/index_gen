# Deep Linear GCNs: Asymptotic Behavior
  
[[GDL_SummerSchool_Part1]] (Page 63)

![[assets/slide-63.jpg]]

## Front
Deep Linear GCNs: Asymptotic Behavior

## Back
The asymptotic behavior of Deep Linear Graph Convolutional Networks (GCNs) and their simplicial version is topological. This means that the features converge to a signal depending only on the connected components of the graph and their respective node degrees.
