# What are k-chains?
  
[[GDL_SummerSchool_Part1]] (Page 38)

![[assets/slide-38.jpg]]

## Front
What are k-chains?

## Back
A k-chain C_k(K, R) is a vector space with real coefficients, using the oriented k-simplices of K as its basis. For example, a 1-chain c_1 can be expressed as a linear combination of oriented 1-simplices (edges):
c_1 = 2.5(0, 1) - (3, 4) + 3.14(1, 3)
Which is equivalent to:
c_1 = 2.5(0, 1) + (4, 3) + 3.14(1, 3)
