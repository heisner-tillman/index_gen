# Defining Topological Deep Learning
  
[[GDL_SummerSchool_Part1]] (Page 4)

![[assets/slide-4.jpg]]

## Front
Defining Topological Deep Learning

## Back
Topological Deep Learning is a research program that explores two main areas:
- Applying deep learning techniques to data that is intrinsically associated with topological spaces.
- Analyzing and understanding the topological characteristics and structures inherent in machine learning models.
The accompanying diagram illustrates data (DATA(U), DATA(W), DATA(V)) linked to specific subsets (U, W, V) within a larger topological space (X), where W is the intersection of U and V.
