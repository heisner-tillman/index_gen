# Chain Complex Convolution and Non-linearity
  
[[GDL_SummerSchool_Part1]] (Page 81)

![[assets/slide-81.jpg]]

## Front
Chain Complex Convolution and Non-linearity

## Back
Convolutions operate on chain complexes, which are sequences of vector spaces connected by boundary maps. Boundary matrices facilitate communication between different dimensions within the chain. The convolution operation is defined by the formula: Y = \psi(L_1\downarrow X_1W_1 + L_1\uparrow X_1W_2 + B_1^\top X_0W_3 + B_2X_2W_4 + X_1W_5). A key proposition states that the activation function \psi must be non-linear for simplices that are more than two dimensions apart to communicate effectively.
