# Poincaré on Topology & Geometry
  
[[GDL_SummerSchool_Part1]] (Page 16)

![[assets/slide-16.jpg]]

## Front
Poincaré on Topology & Geometry

## Back
Henri Poincaré, in "Analysis Situs", viewed topology as the study of invariants of homeomorphisms of a space. He considered topology a subfield of (Klein's) geometry.
