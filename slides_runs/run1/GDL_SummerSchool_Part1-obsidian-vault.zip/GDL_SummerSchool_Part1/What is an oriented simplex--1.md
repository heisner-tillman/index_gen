# What is an oriented simplex?
  
[[GDL_SummerSchool_Part1]] (Page 34)

![[assets/slide-34.jpg]]

## Front
What is an oriented simplex?

## Back
An oriented simplex is a simplex with a specified order of its vertices. It can be visualized as a walk on the simplex following the vertex order.

*   **Representation:**
    *   Oriented simplices are represented as tuples (e.g., (1,2) or (1,2,3)).
    *   Unoriented simplices are represented as sets (e.g., {1,2} or {1,2,3}).

*   **Examples:**
    *   For a 1-simplex {1,2}, orientations include (2,1) and (1,2).
    *   For a 2-simplex {1,2,3}, orientations include (1,2,3) and (1,3,2).
