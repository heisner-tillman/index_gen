# Category Theory: Foundation for Data Processing
  
[[GDL_SummerSchool_Part1]] (Page 14)

![[assets/slide-14.jpg]]

## Front
Category Theory: Foundation for Data Processing

## Back
Category theory, invented by Samuel Eilenberg and Saunders Mac Lane, is a general theory of mathematical structures. It allows for the translation of relations between spaces (e.g., a sphere and a polyhedron) to relations between groups (G1 and G2), providing a framework for data processing.
